package es.ucm.tp1.supercars.logic.instantAction;

import es.ucm.tp1.supercars.logic.Game;

public interface InstantAction {
	
	void execute(Game game);
}

